export interface ZanrovI {
    id:number,
    naziv: string;
    opis: string;
}