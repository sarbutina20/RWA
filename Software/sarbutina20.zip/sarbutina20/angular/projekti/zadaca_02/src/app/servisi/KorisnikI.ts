export interface Korisnik {
    ime:string;
    prezime:string;
    email:string;
    adresa:string;
    korime: string;
}