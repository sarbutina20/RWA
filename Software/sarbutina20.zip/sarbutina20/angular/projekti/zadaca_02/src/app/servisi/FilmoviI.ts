export interface FilmoviI {
    id: number;
    naziv: string;
    opis: string;
    zanr_id: number,
    datum:string,
    odobren:number
}