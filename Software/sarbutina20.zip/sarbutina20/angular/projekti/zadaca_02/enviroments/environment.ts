export const environment = {
    production: false,
    restServis: "http://localhost:12242/api/",
    appServer: "http://localhost:12006/",
    posteriPutanja: "https://image.tmdb.org/t/p/w600_and_h900_bestv2/"
    };