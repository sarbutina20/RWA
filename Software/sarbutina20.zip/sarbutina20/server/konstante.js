module.exports = {
    dirModula : "/usr/lib/node_modules/",
    podaciZaBazu : "/var/www/RWA/2022/bazaPodaci/sarbutina20.json",
    dirPortova: "/var/www/RWA/2022/",
    tajniKljucJWT: "xxx",
    tajniKljucSesija: "yyy"
}